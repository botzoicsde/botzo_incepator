local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

botzo = Proxy.getInterface("vRP")
cBotzo = Tunnel.getInterface("vRP","botzo_incepator")

tcBotzo = Tunnel.getInterface("botzo_incepator","botzo_incepator")

tsBotzo = {}
Tunnel.bindInterface("botzo_incepator",tsBotzo)
Proxy.addInterface("botzo_incepator",tsBotzo)

function refresh()
    local users = botzo.getUsers({})
    for user_id,player in pairs(users) do
        tcBotzo.userNou(-1,{user_id,player,botzo.getUserHoursPlayed({user_id})})
    end
end

RegisterCommand("testechats", function(source, args, msg)
    refresh()
end)

AddEventHandler("vRP:playerSpawn",function(user_id, source, first_spawn)
    refresh()
end)

AddEventHandler("vRP:playerLeave",function(user_id, source)
	tcBotzo.delUser(-1,{user_id})
end)

local css_stats = [[
	.div_rpg_stats{
		background-color: rgba(0,0,0,0.75);
		color: white;
		font-weight: bold;
		width: 500px;
		padding: 10px;
		margin: auto;
		margin-top: 150px;
		text-align: center;
		border-radius: 15px;
	}

	.strike {
		display: block;
		text-align: center;
		overflow: hidden;
		white-space: nowrap;
	}
	.strike > span {
		position: relative;
		display: inline-block;
	}
	.strike > span:before,
	.strike > span:after {
		content: "";
		position: absolute;
		top: 50%;
		width: 9999px;
		height: 1px;
		background: #f27515;
	}
	.strike > span:before {
		right: 100%;
		margin-right: 15px;
	}
	.strike > span:after {
		left: 100%;
		margin-left: 15px;
	}
]]

local function ShowStats(player)
	local user_id = botzo.getUserId({player})
    local msg = ""
    msg = msg .. [[
        <div class="strike">
            <span>STATUS</span>
        </div><br/>
    ]]
    msg = msg .. "ID: " .. user_id .. " | Nume: " .. GetPlayerName(player) .. " | Ore jucate: " .. botzo.getUserHoursPlayed({user_id}) .. "<br/>"	
    msg = msg .. [[
        <br/><br/><div class="strike">
            <span>STATUS</span>
        </div>
    ]]


    cBotzo.setDiv(player, {"vezidacaeincepatornabu", css_stats, msg})
    botzo.request({player, "Inchide", 1000, function(player, ok)
        cBotzo.removeDiv(player, {"vezidacaeincepatornabu"})
    end})
end

RegisterCommand('stats', function(source, args, msg)
	ShowStats(source, source)
end)