tcBotzo = {}
Tunnel.bindInterface("botzo_incepator",tcBotzo)
Proxy.addInterface("botzo_incepator",tcBotzo)
tsBotzo = Tunnel.getInterface("botzo_incepator","botzo_incepator")
botzo = Proxy.getInterface("vRP")

local useri = {}

function tcBotzo.userNou(user_id,source,level,hr)
    useri[user_id] = {player = GetPlayerFromServerId(source),ore=hr,levelj = level}
end

function tcBotzo.delUser(user_id)
    useri[user_id] = nil
end

local fontId

Citizen.CreateThread(function()
	RegisterFontFile('fontname')
	fontId = RegisterFontId('Lemon Milk')
end)

Citizen.CreateThread(function()
    while true do
        for i=0,256 do N_0x31698aa80e0223f8(i)
        end

        for k,v in pairs(useri) do
            local target = GetPlayerPed(v.player)
            local jucatorow = GetPlayerPed(-1)

			if ((target ~= jucatorow)) then
				local x1, y1, z1 = table.unpack(GetEntityCoords(target, true))
				local x2, y2, z2 = table.unpack(GetEntityCoords(jucatorow, true))
				local distance = math.floor(GetDistanceBetweenCoords(x1,  y1,  z1,  x2,  y2,  z2,  true))

                if ((distance < 15.0)) then
                    local off = 0.85
                    if NetworkIsPlayerTalking(v.player) then
                        text = "~g~(~w~"..k.."~g~)"
                    else
                        text = "~y~(~w~"..k.."~y~)"
                    end
                    off = off + 0.130
                    if(v.ore <= 3.0) then
                        text = text.."\n~y~(~w~INCEPATOR~y~)~w~"
                    end
                    DrawText3D(x1,y1,z1+off,text)
				end  
			end
        end

        Citizen.Wait(0)
    end
end)





function DrawText3D(x,y,z, text)
    local onScreen,_x,_y = World3dToScreen2d(x,y,z)
    local px,py,pz = table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*1.5
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov
   
    if onScreen then
        SetTextScale(0.0*scale, 0.55*scale)
        SetTextFont(1)
        SetTextProportional(1)
        SetTextColour(255,255,255,255)
        SetTextDropshadow(0, 0, 0, 0, 100)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    end
end
